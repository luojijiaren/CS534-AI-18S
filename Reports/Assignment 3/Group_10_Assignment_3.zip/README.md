### Assignment 3

## Program Input 
1. The program has options, Basic EM and Extended EM
2. Input 1 for Basic EM and 2 for Extended EM
3. The program requried to input the path of the file


## Program Output
1. For Basic EM, the program will plot the log-likelihood vs. iteration
2. For Extended EM, the program will output different BIC value  


